-- AlterTable
ALTER TABLE "coach_profiles" ADD COLUMN "phone" TEXT;
