-- AlterTable
ALTER TABLE "User" ADD COLUMN "signup_role" TEXT;
