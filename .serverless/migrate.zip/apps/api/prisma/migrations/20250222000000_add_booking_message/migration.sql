-- AlterTable
ALTER TABLE "bookings" ADD COLUMN "message" TEXT;
